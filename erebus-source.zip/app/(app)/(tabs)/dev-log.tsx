import React, { useEffect, useState, useCallback } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Pressable, 
  ActivityIndicator, 
  Alert, 
  Modal, 
  TextInput,
  FlatList,
  Platform,
  RefreshControl,
  KeyboardAvoidingView
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { Ionicons, Feather } from '@expo/vector-icons';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'expo-router';
import { authFetch } from '@/utils/authFetch';
import PageHeader from '@/components/PageHeader';
import ThemedBackground from '@/components/ThemedBackground';

interface DevLogEntry {
  id: number;
  task: string;
  pageName: string | null;
  pageType: 'card' | 'detail' | 'edit';
  status: 'todo' | 'in_progress' | 'completed';
  devices: ('android' | 'ios' | 'web')[];
  createdAt: string;
  updatedAt: string;
}

const STATUS_COLORS = {
  todo: { bg: '#4A5568', text: '#FFFFFF', label: 'To Do' },
  in_progress: { bg: '#D69E2E', text: '#000000', label: 'In Progress' },
  completed: { bg: '#38A169', text: '#FFFFFF', label: 'Completed' },
};

const PAGE_TYPE_COLORS = {
  card: { bg: '#3182CE', text: '#FFFFFF' },
  detail: { bg: '#805AD5', text: '#FFFFFF' },
  edit: { bg: '#DD6B20', text: '#FFFFFF' },
};

const DEVICE_COLORS = {
  android: { bg: '#3DDC84', text: '#000000', label: 'Android' },
  ios: { bg: '#007AFF', text: '#FFFFFF', label: 'iOS' },
  web: { bg: '#FF6B35', text: '#FFFFFF', label: 'Web' },
};

export default function DevLogScreen() {
  const { colors } = useTheme();
  const { token, isAdmin } = useAuth();
  const router = useRouter();
  const [entries, setEntries] = useState<DevLogEntry[]>([]);
  const [pageNames, setPageNames] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [editingEntry, setEditingEntry] = useState<DevLogEntry | null>(null);
  const [showPageNameSuggestions, setShowPageNameSuggestions] = useState(false);
  
  const [formData, setFormData] = useState({
    task: '',
    pageName: '',
    pageType: 'card' as 'card' | 'detail' | 'edit',
    status: 'todo' as 'todo' | 'in_progress' | 'completed',
    devices: [] as ('android' | 'ios' | 'web')[],
  });

  const [activeTab, setActiveTab] = useState<'active' | 'completed'>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const [statusCounts, setStatusCounts] = useState<{ todo: number; in_progress: number; completed: number }>({ todo: 0, in_progress: 0, completed: 0 });
  const [refreshing, setRefreshing] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'todo' | 'in_progress'>('all');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!isAdmin) {
      router.replace('/' as any);
      return;
    }
    fetchEntries();
    fetchPageNames();
    fetchStatusCounts();
  }, [isAdmin]);

  const fetchEntries = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await authFetch('/api/admin/dev-log', token);

      if (response.ok) {
        const data = await response.json();
        setEntries(data);
      } else if (response.status !== 401) {
        setError('Failed to load dev log');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  const fetchPageNames = async () => {
    try {
      const response = await authFetch('/api/admin/dev-log/page-names', token);

      if (response.ok) {
        const data = await response.json();
        setPageNames(data);
      }
    } catch (err) {
      console.error('Failed to fetch page names:', err);
    }
  };

  const fetchStatusCounts = async () => {
    try {
      const response = await authFetch('/api/admin/dev-log', token);

      if (response.ok) {
        const allEntries: DevLogEntry[] = await response.json();
        const counts = { todo: 0, in_progress: 0, completed: 0 };
        allEntries.forEach(entry => {
          if (entry.status in counts) {
            counts[entry.status]++;
          }
        });
        setStatusCounts(counts);
      }
    } catch (err) {
      console.error('Failed to fetch status counts:', err);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([fetchEntries(), fetchStatusCounts()]);
    setRefreshing(false);
  }, [fetchEntries]);

  useEffect(() => {
    if (token) {
      fetchEntries();
    }
  }, [token, fetchEntries]);

  const openAddModal = () => {
    setEditingEntry(null);
    setFormData({ task: '', pageName: '', pageType: 'card', status: 'todo', devices: [] });
    setModalVisible(true);
  };

  const openEditModal = (entry: DevLogEntry) => {
    setEditingEntry(entry);
    setFormData({
      task: entry.task,
      pageName: entry.pageName || '',
      pageType: entry.pageType,
      status: entry.status,
      devices: entry.devices || [],
    });
    setModalVisible(true);
  };

  const toggleDevice = (device: 'android' | 'ios' | 'web') => {
    setFormData(prev => ({
      ...prev,
      devices: prev.devices.includes(device)
        ? prev.devices.filter(d => d !== device)
        : [...prev.devices, device]
    }));
  };

  const handleSave = async () => {
    if (!formData.task.trim()) {
      Alert.alert('Error', 'Task is required');
      return;
    }

    if (isSaving) return;
    setIsSaving(true);

    try {
      const url = editingEntry 
        ? `/api/admin/dev-log/${editingEntry.id}`
        : `/api/admin/dev-log`;
      
      const response = await authFetch(url, token, {
        method: editingEntry ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setModalVisible(false);
        fetchEntries();
        fetchPageNames();
        fetchStatusCounts();
      } else if (response.status !== 401) {
        Alert.alert('Error', 'Failed to save entry');
      }
    } catch (err) {
      Alert.alert('Error', 'Network error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = (entry: DevLogEntry) => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const response = await authFetch(`/api/admin/dev-log/${entry.id}`, token, {
                method: 'DELETE',
              });

              if (response.ok) {
                fetchEntries();
                fetchStatusCounts();
              } else if (response.status !== 401) {
                Alert.alert('Error', 'Failed to delete entry');
              }
            } catch (err) {
              Alert.alert('Error', 'Network error');
            }
          },
        },
      ]
    );
  };

  const filteredSuggestions = pageNames.filter(name => 
    name.toLowerCase().includes(formData.pageName.toLowerCase()) && 
    name.toLowerCase() !== formData.pageName.toLowerCase()
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const showToast = () => {
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 2000);
  };

  const copyEntryToClipboard = async (entry: DevLogEntry) => {
    const devices = entry.devices?.length > 0 ? entry.devices.join(', ') : 'Not specified';
    
    const formattedText = `**Dev Task: ${entry.task}**

- **Page**: ${entry.pageName || 'N/A'} (${entry.pageType})
- **Target Devices**: ${devices}

Please help me with this development task.`;

    try {
      if (Platform.OS === 'web' && navigator?.clipboard) {
        await navigator.clipboard.writeText(formattedText);
        showToast();
      } else {
        await Clipboard.setStringAsync(formattedText);
        showToast();
      }
    } catch (err) {
      console.error('Clipboard error:', err);
      Alert.alert('Error', 'Failed to copy to clipboard');
    }
  };

  const renderEntry = (entry: DevLogEntry) => {
    const statusConfig = STATUS_COLORS[entry.status];
    const pageTypeConfig = PAGE_TYPE_COLORS[entry.pageType];

    return (
      <Pressable
        key={entry.id}
        style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
        onPress={() => openEditModal(entry)}
      >
        <View style={styles.cardHeader}>
          <Text style={[styles.dateText, { color: colors.textSecondary }]}>
            {formatDate(entry.createdAt)}
          </Text>
          <View style={styles.cardActions}>
            <Pressable onPress={() => copyEntryToClipboard(entry)} hitSlop={8} style={styles.actionButton}>
              <Feather name="copy" size={18} color={colors.primary} />
            </Pressable>
            <Pressable onPress={() => handleDelete(entry)} hitSlop={8} style={styles.actionButton}>
              <Feather name="trash-2" size={18} color={colors.error} />
            </Pressable>
          </View>
        </View>

        <Text style={[styles.taskText, { color: colors.text }]} numberOfLines={3}>
          {entry.task}
        </Text>

        <View style={styles.badgeContainer}>
          {entry.pageName && (
            <View style={[styles.badge, { backgroundColor: colors.primary + '20' }]}>
              <Text style={[styles.badgeText, { color: colors.primary }]}>
                {entry.pageName}
              </Text>
            </View>
          )}
          <View style={[styles.badge, { backgroundColor: pageTypeConfig.bg }]}>
            <Text style={[styles.badgeText, { color: pageTypeConfig.text }]}>
              {entry.pageType.charAt(0).toUpperCase() + entry.pageType.slice(1)}
            </Text>
          </View>
          {entry.devices && entry.devices.map((device) => (
            DEVICE_COLORS[device] && (
              <View key={device} style={[styles.badge, { backgroundColor: DEVICE_COLORS[device].bg }]}>
                <Text style={[styles.badgeText, { color: DEVICE_COLORS[device].text }]}>
                  {DEVICE_COLORS[device].label}
                </Text>
              </View>
            )
          ))}
          <View style={[styles.badge, { backgroundColor: statusConfig.bg }]}>
            <Text style={[styles.badgeText, { color: statusConfig.text }]}>
              {statusConfig.label}
            </Text>
          </View>
        </View>
      </Pressable>
    );
  };

  if (!isAdmin) {
    return null;
  }

  return (
    <ThemedBackground>
      <PageHeader title="Dev Log" />

      <View style={styles.searchContainer}>
        <View style={[styles.searchInputContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Feather name="search" size={18} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.text }]}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search tasks..."
            placeholderTextColor={colors.textSecondary}
          />
          {searchQuery.length > 0 && (
            <Pressable onPress={() => setSearchQuery('')} hitSlop={8}>
              <Feather name="x" size={18} color={colors.textSecondary} />
            </Pressable>
          )}
        </View>
      </View>

      <View style={styles.tabContainer}>
        <Pressable
          style={[
            styles.tab,
            { borderBottomColor: activeTab === 'active' ? colors.primary : 'transparent' }
          ]}
          onPress={() => { setActiveTab('active'); setStatusFilter('all'); }}
        >
          <Text style={[styles.tabText, { color: activeTab === 'active' ? colors.primary : colors.textSecondary }]}>
            Active
          </Text>
          <View style={[styles.tabBadge, { backgroundColor: activeTab === 'active' ? colors.primary : colors.surface }]}>
            <Text style={[styles.tabBadgeText, { color: activeTab === 'active' ? '#FFFFFF' : colors.text }]}>
              {statusCounts.todo + statusCounts.in_progress}
            </Text>
          </View>
        </Pressable>
        <Pressable
          style={[
            styles.tab,
            { borderBottomColor: activeTab === 'completed' ? colors.primary : 'transparent' }
          ]}
          onPress={() => setActiveTab('completed')}
        >
          <Text style={[styles.tabText, { color: activeTab === 'completed' ? colors.primary : colors.textSecondary }]}>
            Completed
          </Text>
          <View style={[styles.tabBadge, { backgroundColor: activeTab === 'completed' ? colors.primary : colors.surface }]}>
            <Text style={[styles.tabBadgeText, { color: activeTab === 'completed' ? '#FFFFFF' : colors.text }]}>
              {statusCounts.completed}
            </Text>
          </View>
        </Pressable>
      </View>

      {activeTab === 'active' && (
        <View style={styles.filterContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterScroll}>
            <Pressable
              style={[
                styles.filterChip,
                { 
                  backgroundColor: statusFilter === 'all' ? colors.primary : colors.surface,
                  borderColor: statusFilter === 'all' ? colors.primary : colors.border 
                }
              ]}
              onPress={() => setStatusFilter('all')}
            >
              <Text style={[styles.filterChipText, { color: statusFilter === 'all' ? '#FFFFFF' : colors.text }]}>
                All
              </Text>
              <View style={[styles.filterBadge, { backgroundColor: statusFilter === 'all' ? 'rgba(255,255,255,0.3)' : colors.border }]}>
                <Text style={[styles.filterBadgeText, { color: statusFilter === 'all' ? '#FFFFFF' : colors.text }]}>
                  {statusCounts.todo + statusCounts.in_progress}
                </Text>
              </View>
            </Pressable>
            <Pressable
              style={[
                styles.filterChip,
                { 
                  backgroundColor: statusFilter === 'todo' ? STATUS_COLORS.todo.bg : colors.surface,
                  borderColor: statusFilter === 'todo' ? STATUS_COLORS.todo.bg : colors.border 
                }
              ]}
              onPress={() => setStatusFilter('todo')}
            >
              <Text style={[styles.filterChipText, { color: statusFilter === 'todo' ? STATUS_COLORS.todo.text : colors.text }]}>
                To Do
              </Text>
              <View style={[styles.filterBadge, { backgroundColor: statusFilter === 'todo' ? 'rgba(255,255,255,0.3)' : colors.border }]}>
                <Text style={[styles.filterBadgeText, { color: statusFilter === 'todo' ? STATUS_COLORS.todo.text : colors.text }]}>
                  {statusCounts.todo}
                </Text>
              </View>
            </Pressable>
            <Pressable
              style={[
                styles.filterChip,
                { 
                  backgroundColor: statusFilter === 'in_progress' ? STATUS_COLORS.in_progress.bg : colors.surface,
                  borderColor: statusFilter === 'in_progress' ? STATUS_COLORS.in_progress.bg : colors.border 
                }
              ]}
              onPress={() => setStatusFilter('in_progress')}
            >
              <Text style={[styles.filterChipText, { color: statusFilter === 'in_progress' ? STATUS_COLORS.in_progress.text : colors.text }]}>
                In Progress
              </Text>
              <View style={[styles.filterBadge, { backgroundColor: statusFilter === 'in_progress' ? 'rgba(0,0,0,0.2)' : colors.border }]}>
                <Text style={[styles.filterBadgeText, { color: statusFilter === 'in_progress' ? STATUS_COLORS.in_progress.text : colors.text }]}>
                  {statusCounts.in_progress}
                </Text>
              </View>
            </Pressable>
          </ScrollView>
        </View>
      )}

      {isLoading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : error ? (
        <View style={styles.centerContainer}>
          <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
          <Pressable style={[styles.retryButton, { backgroundColor: colors.primary }]} onPress={fetchEntries}>
            <Text style={styles.retryButtonText}>Retry</Text>
          </Pressable>
        </View>
      ) : entries.length === 0 ? (
        <View style={styles.centerContainer}>
          <Feather name="clipboard" size={48} color={colors.textSecondary} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No dev log entries yet
          </Text>
          <Text style={[styles.emptySubtext, { color: colors.textSecondary }]}>
            Tap the + button to add one
          </Text>
        </View>
      ) : (
        <ScrollView 
          style={styles.scrollView} 
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} tintColor={colors.primary} />
          }
        >
          {entries
            .filter(entry => {
              if (activeTab === 'completed') {
                if (entry.status !== 'completed') return false;
              } else {
                if (entry.status === 'completed') return false;
                if (statusFilter !== 'all' && entry.status !== statusFilter) return false;
              }
              if (!searchQuery.trim()) return true;
              const query = searchQuery.toLowerCase();
              return (
                entry.task.toLowerCase().includes(query) ||
                (entry.pageName && entry.pageName.toLowerCase().includes(query))
              );
            })
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .map(renderEntry)}
        </ScrollView>
      )}

      <Pressable
        style={[styles.fab, { backgroundColor: colors.primary }]}
        onPress={openAddModal}
      >
        <Ionicons name="add" size={28} color="#FFFFFF" />
      </Pressable>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <KeyboardAvoidingView 
          style={styles.modalOverlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>
                {editingEntry ? 'Edit Entry' : 'Add Entry'}
              </Text>
              <Pressable onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </Pressable>
            </View>

            <ScrollView style={styles.modalScrollContent} showsVerticalScrollIndicator={false}>
            <Text style={[styles.label, { color: colors.text }]}>Task *</Text>
            <TextInput
              style={[styles.input, styles.textArea, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              value={formData.task}
              onChangeText={(text) => setFormData({ ...formData, task: text })}
              placeholder="Describe the task..."
              placeholderTextColor={colors.textSecondary}
              multiline
              numberOfLines={3}
            />

            <Text style={[styles.label, { color: colors.text }]}>Page Name</Text>
            <View style={styles.autocompleteContainer}>
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
                value={formData.pageName}
                onChangeText={(text) => {
                  setFormData({ ...formData, pageName: text });
                  setShowPageNameSuggestions(true);
                }}
                onFocus={() => setShowPageNameSuggestions(true)}
                onBlur={() => setTimeout(() => setShowPageNameSuggestions(false), 200)}
                placeholder="e.g., DiveSiteDetail, DiveLogCard"
                placeholderTextColor={colors.textSecondary}
              />
              {showPageNameSuggestions && filteredSuggestions.length > 0 && (
                <View style={[styles.suggestionsContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  {filteredSuggestions.slice(0, 5).map((suggestion) => (
                    <Pressable
                      key={suggestion}
                      style={[styles.suggestionItem, { borderBottomColor: colors.border }]}
                      onPress={() => {
                        setFormData({ ...formData, pageName: suggestion });
                        setShowPageNameSuggestions(false);
                      }}
                    >
                      <Text style={[styles.suggestionText, { color: colors.text }]}>{suggestion}</Text>
                    </Pressable>
                  ))}
                </View>
              )}
            </View>

            <Text style={[styles.label, { color: colors.text }]}>Page Type</Text>
            <View style={styles.optionsRow}>
              {(['card', 'detail', 'edit'] as const).map((type) => {
                const config = PAGE_TYPE_COLORS[type];
                const isSelected = formData.pageType === type;
                return (
                  <Pressable
                    key={type}
                    style={[
                      styles.optionButton,
                      { backgroundColor: isSelected ? config.bg : colors.background, borderColor: config.bg }
                    ]}
                    onPress={() => setFormData({ ...formData, pageType: type })}
                  >
                    <Text style={[styles.optionText, { color: isSelected ? config.text : colors.text }]}>
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={[styles.label, { color: colors.text }]}>Status</Text>
            <View style={styles.optionsRow}>
              {(['todo', 'in_progress', 'completed'] as const).map((status) => {
                const config = STATUS_COLORS[status];
                const isSelected = formData.status === status;
                return (
                  <Pressable
                    key={status}
                    style={[
                      styles.optionButton,
                      { backgroundColor: isSelected ? config.bg : colors.background, borderColor: config.bg }
                    ]}
                    onPress={() => setFormData({ ...formData, status })}
                  >
                    <Text style={[styles.optionText, { color: isSelected ? config.text : colors.text }]}>
                      {config.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={[styles.label, { color: colors.text }]}>Device (select multiple)</Text>
            <View style={styles.optionsRow}>
              {(['android', 'ios', 'web'] as const).map((device) => {
                const config = DEVICE_COLORS[device];
                const isSelected = formData.devices.includes(device);
                return (
                  <Pressable
                    key={device}
                    style={[
                      styles.optionButton,
                      { backgroundColor: isSelected ? config.bg : colors.background, borderColor: config.bg }
                    ]}
                    onPress={() => toggleDevice(device)}
                  >
                    <Text style={[styles.optionText, { color: isSelected ? config.text : colors.text }]}>
                      {config.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Pressable
              style={[styles.saveButton, { backgroundColor: colors.primary, opacity: isSaving ? 0.6 : 1 }]}
              onPress={handleSave}
              disabled={isSaving}
            >
              {isSaving ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <Text style={styles.saveButtonText}>
                  {editingEntry ? 'Update' : 'Add Entry'}
                </Text>
              )}
            </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {toastVisible && (
        <View style={styles.toastContainer}>
          <View style={[styles.toast, { backgroundColor: colors.primary }]}>
            <Feather name="check" size={18} color="#FFFFFF" />
            <Text style={styles.toastText}>Copied to clipboard</Text>
          </View>
        </View>
      )}
    </ThemedBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 16,
    borderBottomWidth: 1,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    padding: 0,
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderBottomWidth: 2,
    gap: 8,
  },
  tabText: {
    fontSize: 15,
    fontWeight: '600',
  },
  tabBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    minWidth: 24,
    alignItems: 'center',
  },
  tabBadgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  filterContainer: {
    paddingVertical: 12,
  },
  filterScroll: {
    paddingHorizontal: 16,
    gap: 8,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    marginRight: 6,
    gap: 6,
  },
  filterChipText: {
    fontSize: 12,
    fontWeight: '500',
  },
  filterBadge: {
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 8,
    minWidth: 20,
    alignItems: 'center',
  },
  filterBadgeText: {
    fontSize: 11,
    fontWeight: '600',
  },
  badge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    marginBottom: 16,
    textAlign: 'center',
  },
  retryButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    marginTop: 8,
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  actionButton: {
    padding: 4,
  },
  dateText: {
    fontSize: 12,
  },
  taskText: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 12,
    lineHeight: 22,
  },
  badgeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '90%',
  },
  modalScrollContent: {
    flexGrow: 0,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 12,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  autocompleteContainer: {
    position: 'relative',
    zIndex: 10,
  },
  suggestionsContainer: {
    position: 'absolute',
    top: '100%',
    left: 0,
    right: 0,
    borderWidth: 1,
    borderTopWidth: 0,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    maxHeight: 150,
    zIndex: 100,
  },
  suggestionItem: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  suggestionText: {
    fontSize: 14,
  },
  optionsRow: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  optionButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1.5,
    flex: 1,
    minWidth: 60,
    alignItems: 'center',
  },
  optionText: {
    fontSize: 12,
    fontWeight: '600',
  },
  saveButton: {
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  toastContainer: {
    position: 'absolute',
    bottom: 100,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 1000,
  },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
});
