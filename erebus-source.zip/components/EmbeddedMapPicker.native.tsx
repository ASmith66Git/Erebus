import React, { useState, useEffect, useRef, useCallback, useMemo, Component, ErrorInfo, ReactNode } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Platform,
  Pressable,
  ActivityIndicator,
  Keyboard,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as Location from 'expo-location';
import Constants from 'expo-constants';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';

// Error boundary to catch crashes in react-native-maps
interface MapErrorBoundaryProps {
  children: ReactNode;
  fallback: ReactNode;
  onError?: (error: Error) => void;
}

interface MapErrorBoundaryState {
  hasError: boolean;
}

class MapErrorBoundary extends Component<MapErrorBoundaryProps, MapErrorBoundaryState> {
  constructor(props: MapErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(_: Error): MapErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('MapErrorBoundary caught error:', error.message);
    console.error('Component stack:', errorInfo.componentStack);
    this.props.onError?.(error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

interface PlaceData {
  country?: string;
  region?: string;
  formattedAddress?: string;
}

interface EmbeddedMapPickerProps {
  latitude: number;
  longitude: number;
  onCoordinatesChange: (lat: number, lng: number) => void;
  onPlaceSelect?: (placeData: PlaceData) => void;
  colors: {
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
    border: string;
    primary: string;
  };
  readOnly?: boolean;
}

function loadMapsModule() {
  try {
    if (Platform.OS !== 'web') {
      const maps = require('react-native-maps');
      return { MapView: maps.default, Marker: maps.Marker };
    }
  } catch (e) {
    console.log('react-native-maps not available:', e);
  }
  return { MapView: null, Marker: null };
}

export default function EmbeddedMapPicker({
  latitude,
  longitude,
  onCoordinatesChange,
  onPlaceSelect,
  colors,
  readOnly = false,
}: EmbeddedMapPickerProps) {
  const [searchText, setSearchText] = useState('');
  const [markerPosition, setMarkerPosition] = useState({ latitude, longitude });
  const [gettingLocation, setGettingLocation] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);
  const mapRef = useRef<any>(null);
  const webMapRef = useRef<HTMLDivElement | null>(null);
  const googleMapRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const autocompleteRef = useRef<any>(null);

  // API key lookup - try multiple sources for production compatibility
  const apiKey = process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY || 
    Constants.expoConfig?.extra?.googleMapsApiKey || 
    (Constants as any).manifest?.extra?.googleMapsApiKey ||
    (Constants as any).manifest2?.extra?.expoClient?.extra?.googleMapsApiKey ||
    '';
    
  const androidApiKey = 
    Constants.expoConfig?.extra?.googleMapsAndroidApiKey || 
    (Constants as any).manifest?.extra?.googleMapsAndroidApiKey ||
    (Constants as any).manifest2?.extra?.expoClient?.extra?.googleMapsAndroidApiKey ||
    process.env.GOOGLE_MAPS_ANDROID_API_KEY || 
    '';

  // Load maps module lazily inside the component to catch any initialization errors
  const [mapsModule, setMapsModule] = useState<{ MapView: any; Marker: any } | null>(null);
  const [mapsLoadError, setMapsLoadError] = useState(false);

  useEffect(() => {
    try {
      const module = loadMapsModule();
      if (module.MapView) {
        setMapsModule(module);
      } else {
        setMapsLoadError(true);
      }
    } catch (e) {
      console.error('Failed to load maps module:', e);
      setMapsLoadError(true);
    }
  }, []);

  const { MapView, Marker } = mapsModule || { MapView: null, Marker: null };

  // For Android native maps, the API key is baked into the build via app.config.js android.config.googleMaps.apiKey
  // Check if the androidApiKey was set in the config - if empty, maps will crash on Android
  const hasValidAndroidKey = Platform.OS !== 'android' || (androidApiKey && androidApiKey.length > 10);
  
  // Log for debugging in case of issues
  useEffect(() => {
    if (Platform.OS === 'android') {
      console.log('EmbeddedMapPicker: Android native maps rendering, coordinates:', latitude, longitude);
      console.log('EmbeddedMapPicker: Android API key configured:', hasValidAndroidKey);
    }
  }, [latitude, longitude, hasValidAndroidKey]);

  useEffect(() => {
    setMarkerPosition({ latitude, longitude });
  }, [latitude, longitude]);

  const handleMarkerChange = useCallback((lat: number, lng: number) => {
    setMarkerPosition({ latitude: lat, longitude: lng });
    onCoordinatesChange(lat, lng);
  }, [onCoordinatesChange]);

  const handlePlaceSelect = useCallback((data: any, details: any) => {
    if (details?.geometry?.location) {
      const lat = details.geometry.location.lat;
      const lng = details.geometry.location.lng;
      setMarkerPosition({ latitude: lat, longitude: lng });
      onCoordinatesChange(lat, lng);
      
      if (onPlaceSelect && details.address_components) {
        let country: string | undefined;
        let region: string | undefined;
        
        for (const component of details.address_components) {
          const types = component.types || [];
          if (types.includes('country')) {
            country = component.long_name;
          }
          if (types.includes('administrative_area_level_1')) {
            region = component.long_name;
          }
          if (!region && types.includes('administrative_area_level_2')) {
            region = component.long_name;
          }
        }
        
        onPlaceSelect({
          country,
          region,
          formattedAddress: details.formatted_address,
        });
      }
      
      if (mapRef.current) {
        mapRef.current.animateToRegion({
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
      Keyboard.dismiss();
    }
  }, [onCoordinatesChange, onPlaceSelect]);

  const getCurrentLocation = async () => {
    setGettingLocation(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        return;
      }
      const location = await Location.getCurrentPositionAsync({});
      const lat = location.coords.latitude;
      const lng = location.coords.longitude;
      handleMarkerChange(lat, lng);
      
      if (Platform.OS === 'web' && googleMapRef.current) {
        googleMapRef.current.setCenter({ lat, lng });
        if (markerRef.current) {
          markerRef.current.setPosition({ lat, lng });
        }
      } else if (mapRef.current) {
        mapRef.current.animateToRegion({
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (error) {
      console.error('Error getting location:', error);
    } finally {
      setGettingLocation(false);
    }
  };

  useEffect(() => {
    if (Platform.OS !== 'web') return;
    if (googleMapRef.current) return;
    if (!apiKey) {
      setMapError('Google Maps API key not configured');
      return;
    }

    const initWebMap = async () => {
      const mapElement = webMapRef.current;
      if (!mapElement) {
        setTimeout(initWebMap, 100);
        return;
      }

      try {
        let google = (window as any).google;
        
        if (!google || !google.maps) {
          const { setOptions, importLibrary } = await import('@googlemaps/js-api-loader');
          
          setOptions({
            key: apiKey,
            v: 'weekly',
          });
          
          await importLibrary('maps');
          await importLibrary('places');
          
          google = (window as any).google;
        }
        
        if (!google || !google.maps) {
          throw new Error('Google Maps failed to initialize');
        }
        
        const map = new google.maps.Map(mapElement, {
          center: { lat: latitude || 0, lng: longitude || 0 },
          zoom: latitude && longitude ? 12 : 2,
          mapTypeControl: true,
          streetViewControl: false,
          fullscreenControl: false,
        });
        googleMapRef.current = map;

        const marker = new google.maps.Marker({
          position: { lat: latitude || 0, lng: longitude || 0 },
          map: map,
          draggable: true,
        });
        markerRef.current = marker;

        marker.addListener('dragend', () => {
          const pos = marker.getPosition();
          if (pos) {
            handleMarkerChange(pos.lat(), pos.lng());
          }
        });

        map.addListener('click', (e: any) => {
          const lat = e.latLng.lat();
          const lng = e.latLng.lng();
          marker.setPosition({ lat, lng });
          handleMarkerChange(lat, lng);
        });

        setTimeout(() => {
          const searchInput = document.getElementById('map-search-input') as HTMLInputElement;
          if (searchInput && google.maps.places?.Autocomplete) {
            try {
              const autocomplete = new google.maps.places.Autocomplete(searchInput, {
                types: ['geocode', 'establishment'],
              });
              autocompleteRef.current = autocomplete;

              autocomplete.addListener('place_changed', () => {
                const place = autocomplete.getPlace();
                if (place.geometry && place.geometry.location) {
                  const lat = place.geometry.location.lat();
                  const lng = place.geometry.location.lng();
                  map.setCenter({ lat, lng });
                  map.setZoom(14);
                  marker.setPosition({ lat, lng });
                  handleMarkerChange(lat, lng);
                  setSearchText(place.formatted_address || place.name || '');
                }
              });
            } catch (e) {
              console.log('Places Autocomplete not available');
            }
          }
        }, 500);

        setMapLoaded(true);
      } catch (error: any) {
        console.error('Error loading Google Maps:', error?.message || error?.toString() || 'Unknown error');
        setMapError(error?.message || 'Failed to load map. Please check your API key.');
      }
    };

    const timer = setTimeout(initWebMap, 50);
    return () => clearTimeout(timer);
  }, [apiKey, latitude, longitude, handleMarkerChange]);

  useEffect(() => {
    if (Platform.OS === 'web' && googleMapRef.current && markerRef.current) {
      const lat = markerPosition.latitude;
      const lng = markerPosition.longitude;
      markerRef.current.setPosition({ lat, lng });
    }
  }, [markerPosition]);

  if (Platform.OS === 'web') {
    return (
      <View style={styles.container}>
        <View style={styles.searchRow}>
          <View style={[styles.searchInputContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="search" size={18} color={colors.textSecondary} style={styles.searchIcon} />
            <input
              id="map-search-input"
              type="text"
              placeholder="Search for a location..."
              style={{
                flex: 1,
                border: 'none',
                outline: 'none',
                backgroundColor: 'transparent',
                color: colors.text,
                fontSize: 16,
                padding: '8px 0',
                width: '100%',
              }}
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </View>
          <Pressable
            style={[styles.locationButton, { backgroundColor: colors.primary }]}
            onPress={getCurrentLocation}
            disabled={gettingLocation}
          >
            {gettingLocation ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Feather name="crosshair" size={20} color="#FFFFFF" />
            )}
          </Pressable>
        </View>

        <View style={[styles.mapContainer, { borderColor: colors.border }]}>
          {mapError ? (
            <View style={[styles.mapPlaceholder, { backgroundColor: colors.surface }]}>
              <Feather name="alert-circle" size={24} color={colors.textSecondary} />
              <Text style={[styles.mapPlaceholderText, { color: colors.textSecondary }]}>{mapError}</Text>
            </View>
          ) : !mapLoaded ? (
            <View style={[styles.mapPlaceholder, { backgroundColor: colors.surface }]}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[styles.mapPlaceholderText, { color: colors.textSecondary }]}>Loading map...</Text>
            </View>
          ) : null}
          <div
            ref={webMapRef as any}
            style={{
              width: '100%',
              height: 300,
              borderRadius: 8,
              display: mapLoaded && !mapError ? 'block' : 'none',
            }}
          />
        </View>

        <View style={styles.coordsRow}>
          <Text style={[styles.coordsLabel, { color: colors.textSecondary }]}>
            Coordinates:
          </Text>
          <Text style={[styles.coordsValue, { color: colors.text }]}>
            {Number(markerPosition.latitude).toFixed(6)}, {Number(markerPosition.longitude).toFixed(6)}
          </Text>
        </View>

        <Text style={[styles.helpText, { color: colors.textSecondary }]}>
          Search for a location, click on the map, or drag the marker to set coordinates
        </Text>
      </View>
    );
  }

  if (!MapView || mapsLoadError || (Platform.OS === 'android' && !hasValidAndroidKey)) {
    return (
      <View style={[styles.fallbackContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Feather name="map-pin" size={32} color={colors.textSecondary} />
        <Text style={[styles.fallbackText, { color: colors.textSecondary }]}>
          {!hasValidAndroidKey ? 'Map API key not configured' : 'Map not available on this device'}
        </Text>
        <View style={styles.fallbackInputs}>
          <View style={styles.fallbackInputRow}>
            <Text style={[styles.fallbackInputLabel, { color: colors.text }]}>Lat:</Text>
            <TextInput
              style={[styles.fallbackInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.text }]}
              value={markerPosition.latitude.toString()}
              onChangeText={(v) => {
                const lat = parseFloat(v);
                if (!isNaN(lat)) handleMarkerChange(lat, markerPosition.longitude);
              }}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.fallbackInputRow}>
            <Text style={[styles.fallbackInputLabel, { color: colors.text }]}>Lng:</Text>
            <TextInput
              style={[styles.fallbackInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.text }]}
              value={markerPosition.longitude.toString()}
              onChangeText={(v) => {
                const lng = parseFloat(v);
                if (!isNaN(lng)) handleMarkerChange(markerPosition.latitude, lng);
              }}
              keyboardType="numeric"
            />
          </View>
        </View>
        <Pressable
          style={[styles.locationButton, { backgroundColor: colors.primary, marginTop: 12 }]}
          onPress={getCurrentLocation}
          disabled={gettingLocation}
        >
          {gettingLocation ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <>
              <Feather name="crosshair" size={18} color="#FFFFFF" />
              <Text style={styles.locationButtonText}>Use My Location</Text>
            </>
          )}
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.searchRow}>
        <View style={{ flex: 1, marginRight: 8 }}>
          {apiKey && apiKey.length > 10 ? (
            <GooglePlacesAutocomplete
              placeholder="Search for a location..."
              onPress={handlePlaceSelect}
              fetchDetails={true}
              query={{
                key: apiKey,
                language: 'en',
              }}
              styles={{
                container: {
                  flex: 0,
                },
                textInputContainer: {
                  backgroundColor: colors.surface,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: colors.border,
                },
                textInput: {
                  height: 44,
                  color: colors.text,
                  fontSize: 16,
                  backgroundColor: 'transparent',
                },
                listView: {
                  backgroundColor: colors.surface,
                  borderRadius: 8,
                  marginTop: 4,
                  borderWidth: 1,
                  borderColor: colors.border,
                },
                row: {
                  backgroundColor: colors.surface,
                  padding: 13,
                },
                description: {
                  color: colors.text,
                },
                poweredContainer: {
                  display: 'none',
                },
              }}
              enablePoweredByContainer={false}
              minLength={2}
              debounce={300}
            />
          ) : (
            <View style={[styles.searchFallback, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <TextInput
                style={[styles.searchFallbackInput, { color: colors.text }]}
                placeholder="Enter coordinates manually below"
                placeholderTextColor={colors.textSecondary}
                editable={false}
              />
            </View>
          )}
        </View>
        <Pressable
          style={[styles.locationButton, { backgroundColor: colors.primary }]}
          onPress={getCurrentLocation}
          disabled={gettingLocation}
        >
          {gettingLocation ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Feather name="crosshair" size={20} color="#FFFFFF" />
          )}
        </Pressable>
      </View>

      <MapErrorBoundary
        fallback={
          <View style={[styles.fallbackContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="map-pin" size={32} color={colors.textSecondary} />
            <Text style={[styles.fallbackText, { color: colors.textSecondary }]}>
              Map failed to load
            </Text>
            <View style={styles.fallbackInputs}>
              <View style={styles.fallbackInputRow}>
                <Text style={[styles.fallbackInputLabel, { color: colors.text }]}>Lat:</Text>
                <TextInput
                  style={[styles.fallbackInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.text }]}
                  value={markerPosition.latitude.toString()}
                  onChangeText={(v) => {
                    const lat = parseFloat(v);
                    if (!isNaN(lat)) handleMarkerChange(lat, markerPosition.longitude);
                  }}
                  keyboardType="numeric"
                />
              </View>
              <View style={styles.fallbackInputRow}>
                <Text style={[styles.fallbackInputLabel, { color: colors.text }]}>Lng:</Text>
                <TextInput
                  style={[styles.fallbackInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.text }]}
                  value={markerPosition.longitude.toString()}
                  onChangeText={(v) => {
                    const lng = parseFloat(v);
                    if (!isNaN(lng)) handleMarkerChange(markerPosition.latitude, lng);
                  }}
                  keyboardType="numeric"
                />
              </View>
            </View>
          </View>
        }
        onError={(error) => console.error('EmbeddedMapPicker crashed:', error.message)}
      >
        <View style={[styles.mapContainer, { borderColor: colors.border }]}>
          <MapView
            ref={mapRef}
            style={styles.map}
            initialRegion={{
              latitude: latitude || 0,
              longitude: longitude || 0,
              latitudeDelta: latitude && longitude ? 0.05 : 50,
              longitudeDelta: longitude && longitude ? 0.05 : 50,
            }}
            onPress={(e: any) => {
              const { latitude: lat, longitude: lng } = e.nativeEvent.coordinate;
              handleMarkerChange(lat, lng);
            }}
          >
            <Marker
              coordinate={markerPosition}
              draggable
              onDragEnd={(e: any) => {
                const { latitude: lat, longitude: lng } = e.nativeEvent.coordinate;
                handleMarkerChange(lat, lng);
              }}
            />
          </MapView>
        </View>
      </MapErrorBoundary>

      <View style={styles.coordsRow}>
        <Text style={[styles.coordsLabel, { color: colors.textSecondary }]}>
          Coordinates:
        </Text>
        <Text style={[styles.coordsValue, { color: colors.text }]}>
          {Number(markerPosition.latitude).toFixed(6)}, {Number(markerPosition.longitude).toFixed(6)}
        </Text>
      </View>

      <Text style={[styles.helpText, { color: colors.textSecondary }]}>
        Tap on the map or drag the marker to set coordinates
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 8,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 44,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    height: '100%',
  },
  searchFallback: {
    borderWidth: 1,
    borderRadius: 8,
    height: 44,
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  searchFallbackInput: {
    fontSize: 14,
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
    gap: 6,
  },
  locationButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  mapContainer: {
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
  },
  map: {
    width: '100%',
    height: 300,
  },
  mapPlaceholder: {
    width: '100%',
    height: 300,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  mapPlaceholderText: {
    fontSize: 14,
  },
  coordsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    gap: 8,
  },
  coordsLabel: {
    fontSize: 14,
  },
  coordsValue: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
  },
  helpText: {
    fontSize: 12,
    marginTop: 6,
    fontStyle: 'italic',
  },
  fallbackContainer: {
    padding: 20,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: 'center',
    marginTop: 8,
  },
  fallbackText: {
    fontSize: 14,
    marginTop: 8,
    marginBottom: 16,
  },
  fallbackInputs: {
    flexDirection: 'row',
    gap: 16,
  },
  fallbackInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  fallbackInputLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  fallbackInput: {
    width: 120,
    height: 40,
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 10,
    fontSize: 14,
  },
});
